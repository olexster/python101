Scenariusze
#######################

Poniżej zamieszczamy propozycje scenariuszy zajęć wykorzystujących materiały
zgromadzone w repozytorium "Python 101 – materiały Koduj z Klasą".

.. toctree::
    :maxdepth: 3

    materialy.rst
    warsztaty4g.rst
    warsztaty8g.rst
    warsztaty16g.rst