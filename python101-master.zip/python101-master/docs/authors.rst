Autorzy
-------

- `Robert Bednarz <ecg@ecg.vot.pl>`_:
  "System i oprogramowanie", "Podstawy Pythona", "Matplotlib", "Gra robotów", "Gry w Pythonie"
  (wersje strukturalne), "Bazy danych w Pythonie", "Aplikacje okienkowe Qt5",
  "Aplikacje WWW (Flask)", "Aplikacje WWW (Django)", "Minecraft Pi", "Scenariusze"
- `Dorota Rybicka <rybicka.dorota@gmail.com>`_ ("Wprowadzenie do języka Python")
- `Adam Jurkiewicz <biuro@cyfrowaszkola.waw.pl>`_ ("IDE - edytory kodu")
- `Grzegorz Wilczek <grzegorz.wilczek@ceo.org.pl>`_ ("Wprowadzenie do języka Python")
- `Janusz Skonieczny <https://plus.google.com/+JanuszSkonieczny/>`_:
  "System i oprogramowanie", "Przygotowanie katalogu projektu",
  "Gry w Pythonie" (wersje obiektowe), "Git – wersjonowanie kodów źródłowych"
- Paweł Świeczka: "Scenariusze"
- Rafał Brzychcy, Tomasz Nowacki, Łukasz Zarzecki – pomysłodawcy i autorzy
  wyjściowych wersji materiałów:
  "Wprowadzenia do języka Python", "Gry w Pythonie" (wersja strukturalna),
  aplikacji internetowych: Quiz, ToDo, Chatter.
