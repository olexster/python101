#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random

ileliczb = int(input("Podaj ilość typowanych liczb: "))
maksliczba = int(input("Podaj maksymalną losowaną liczbę: "))
# print("Wytypuj", ileliczb, "z", maksliczba, " liczb: ")
print("Wytypuj %s z %s liczb: " % (ileliczb, maksliczba))
