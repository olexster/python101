.. _przyklady:

Python w przykładach
#####################

Poznawanie Pythona zrealizujemy poprzez rozwiązywanie prostych zadań,
które pozwolą zaprezentować elastyczność i łatwość tego języka.
Sugerujemy używanie konsoli Pythona do testowania poznawanych funkcji,
konstrukcji i fragmentów kodu.

.. toctree::
    :titlesonly:

    przyklad00
    przyklad01
    przyklad02
    przyklad03
    przyklad04
    przyklad05
    przyklad06
    przyklad07