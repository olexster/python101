FAQ
===============================


1) Jak utworzyć rozruchowy nośnik USB z dystrybucją Linux? :ref:`»»» <usb-creator>`

2) ...

.. raw:: html

    <style>
        div.code_no { text-align: right; background: #e3e3e3; padding: 6px 12px; }
        div.highlight, div.highlight-python { margin-top: 0px; }
    </style>
