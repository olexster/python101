Alternatywna wersja skryptów do mcpi-sim oparta na klasie
Symulacja zdefiniowanej w pliku mcsym.py, ładowanej i uruchamianej
przez mc.py
