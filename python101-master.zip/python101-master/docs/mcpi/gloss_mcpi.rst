Słownik Minecraft Pi
####################

.. glossary::

  API
    interfejs programistyczny aplikacji (ang. Application Programming Interface) –
    zestaw struktur danych, klas obiektów i metod umożliwiających komunikację
    z aplikacją, biblioteką lub systemem.

